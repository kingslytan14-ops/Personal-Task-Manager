<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Task Manager')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7fb; color: #1f2937; }
        .navbar-brand { font-weight: 700; letter-spacing: .2px; }
        .hero { background: linear-gradient(135deg, #111827, #374151); color: white; border-radius: 20px; }
        .stat-card, .task-card, .form-card { border: 0; border-radius: 18px; box-shadow: 0 8px 25px rgba(15,23,42,.07); }
        .stat-number { font-size: 2rem; font-weight: 800; }
        .task-card { transition: transform .15s ease, box-shadow .15s ease; }
        .task-card:hover { transform: translateY(-2px); box-shadow: 0 12px 30px rgba(15,23,42,.1); }
        .description { white-space: pre-line; color: #6b7280; }
        .badge-pending { background: #fff3cd; color: #8a6100; }
        .badge-completed { background: #d1e7dd; color: #146c43; }
        .empty-state { border: 2px dashed #d1d5db; border-radius: 18px; }
        footer { color: #9ca3af; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="{{ route('tasks.index') }}">✓ Personal Task Manager</a>
        <a class="btn btn-light btn-sm" href="{{ route('tasks.create') }}">+ Add Task</a>
    </div>
</nav>

<main class="container pb-5">
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <strong>Please fix the following:</strong>
            <ul class="mb-0 mt-2">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @yield('content')
</main>

<footer class="text-center py-4">WST21-PM-2026-SF · Laravel Personal Task Manager</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
