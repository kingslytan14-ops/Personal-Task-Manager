@extends('layout')

@section('title', 'My Tasks')

@section('content')
<div class="hero p-4 p-md-5 mb-4">
    <div class="row align-items-center">
        <div class="col-lg-8">
            <p class="text-uppercase small mb-2 opacity-75">Personal productivity</p>
            <h1 class="fw-bold">My Task Dashboard</h1>
            <p class="mb-0 opacity-75">Keep track of your tasks, deadlines, and progress in one simple place.</p>
        </div>
        <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
            <a href="{{ route('tasks.create') }}" class="btn btn-light btn-lg">Create a Task</a>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="card stat-card p-3"><div class="text-muted">Total Tasks</div><div class="stat-number">{{ $totalTasks }}</div></div></div>
    <div class="col-md-4"><div class="card stat-card p-3"><div class="text-muted">Pending</div><div class="stat-number">{{ $pendingTasks }}</div></div></div>
    <div class="col-md-4"><div class="card stat-card p-3"><div class="text-muted">Completed</div><div class="stat-number">{{ $completedTasks }}</div></div></div>
</div>

@if($tasks->isEmpty())
    <div class="card empty-state p-5 text-center bg-white">
        <h3>No tasks yet</h3>
        <p class="text-muted">Create your first task to get started.</p>
        <a href="{{ route('tasks.create') }}" class="btn btn-dark">Add My First Task</a>
    </div>
@else
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h4 mb-0">All Tasks</h2>
        <span class="text-muted small">{{ $totalTasks }} {{ Str::plural('task', $totalTasks) }}</span>
    </div>

    <div class="row g-3">
        @foreach($tasks as $task)
            <div class="col-lg-6">
                <div class="card task-card h-100 bg-white p-3">
                    <div class="d-flex justify-content-between gap-3">
                        <div>
                            <h3 class="h5 mb-1">{{ $task->task_name }}</h3>
                            <div class="small text-muted">Due: {{ $task->due_date->format('M d, Y') }}</div>
                        </div>
                        <span class="badge rounded-pill align-self-start {{ $task->status === 'Completed' ? 'badge-completed' : 'badge-pending' }}">{{ $task->status }}</span>
                    </div>
                    <p class="description mt-3 mb-3">{{ $task->description ?: 'No description provided.' }}</p>
                    <div class="d-flex flex-wrap gap-2 mt-auto">
                        <a href="{{ route('tasks.edit', $task) }}" class="btn btn-outline-dark btn-sm">Edit</a>
                        <form method="POST" action="{{ route('tasks.status', $task) }}" class="d-inline">
                            @csrf @method('PATCH')
                            <input type="hidden" name="status" value="{{ $task->status === 'Completed' ? 'Pending' : 'Completed' }}">
                            <button class="btn btn-outline-success btn-sm">Mark {{ $task->status === 'Completed' ? 'Pending' : 'Completed' }}</button>
                        </form>
                        <form method="POST" action="{{ route('tasks.destroy', $task) }}" class="d-inline" onsubmit="return confirm('Delete this task?');">
                            @csrf @method('DELETE')
                            <button class="btn btn-outline-danger btn-sm">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif
@endsection
