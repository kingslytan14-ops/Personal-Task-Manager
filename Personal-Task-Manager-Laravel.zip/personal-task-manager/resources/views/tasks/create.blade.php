@extends('layout')
@section('title', 'Add Task')
@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card form-card bg-white p-4 p-md-5">
            <h1 class="h3 fw-bold mb-1">Add New Task</h1>
            <p class="text-muted mb-4">Enter the details of your task below.</p>
            <form method="POST" action="{{ route('tasks.store') }}">
                @csrf
                @include('tasks.form')
                <div class="d-flex gap-2 mt-4">
                    <button class="btn btn-dark">Save Task</button>
                    <a href="{{ route('tasks.index') }}" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
