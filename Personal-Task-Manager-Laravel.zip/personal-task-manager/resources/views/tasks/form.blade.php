<div class="mb-3">
    <label for="task_name" class="form-label fw-semibold">Task Name</label>
    <input type="text" id="task_name" name="task_name" class="form-control" value="{{ old('task_name', $task->task_name ?? '') }}" placeholder="e.g. Finish Laravel project" required>
</div>
<div class="mb-3">
    <label for="description" class="form-label fw-semibold">Description</label>
    <textarea id="description" name="description" rows="4" class="form-control" placeholder="Add task details...">{{ old('description', $task->description ?? '') }}</textarea>
</div>
<div class="row g-3">
    <div class="col-md-6">
        <label for="status" class="form-label fw-semibold">Status</label>
        <select id="status" name="status" class="form-select" required>
            <option value="Pending" @selected(old('status', $task->status ?? 'Pending') === 'Pending')>Pending</option>
            <option value="Completed" @selected(old('status', $task->status ?? 'Pending') === 'Completed')>Completed</option>
        </select>
    </div>
    <div class="col-md-6">
        <label for="due_date" class="form-label fw-semibold">Due Date</label>
        <input type="date" id="due_date" name="due_date" class="form-control" value="{{ old('due_date', isset($task) ? $task->due_date->format('Y-m-d') : '') }}" required>
    </div>
</div>
