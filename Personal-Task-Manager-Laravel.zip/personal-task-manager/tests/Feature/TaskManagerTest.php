<?php

namespace Tests\Feature;

use App\Models\Task;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TaskManagerTest extends TestCase
{
    use RefreshDatabase;

    public function test_tasks_page_can_be_viewed(): void
    {
        $response = $this->get('/tasks');
        $response->assertStatus(200);
        $response->assertSee('My Task Dashboard');
    }

    public function test_task_can_be_created(): void
    {
        $response = $this->post('/tasks', [
            'task_name' => 'Finish Laravel project',
            'description' => 'Complete the CRUD project.',
            'status' => 'Pending',
            'due_date' => '2026-09-30',
        ]);

        $response->assertRedirect('/tasks');
        $this->assertDatabaseHas('tasks', ['task_name' => 'Finish Laravel project']);
    }

    public function test_task_can_be_deleted(): void
    {
        $task = Task::create(['task_name' => 'Delete me', 'description' => null, 'status' => 'Pending', 'due_date' => '2026-09-30']);
        $this->delete('/tasks/'.$task->id)->assertRedirect('/tasks');
        $this->assertDatabaseMissing('tasks', ['id' => $task->id]);
    }
}
